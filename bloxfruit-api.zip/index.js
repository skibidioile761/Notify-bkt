require('dotenv').config();
const express = require('express');
const axios   = require('axios');

const app  = express();
const PORT = process.env.PORT || 3000;
const WEBHOOK_URL = process.env.DISCORD_WEBHOOK_URL;

if (!WEBHOOK_URL) {
  console.error('❌ Vui lòng thiết lập DISCORD_WEBHOOK_URL trong .env');
  process.exit(1);
}

app.use(express.json());

app.post('/mirage', async (req, res) => {
  const { type, players, jobId, script } = req.body;
  if (!type || players == null || !jobId || !script) {
    return res.status(400).json({ error: 'Thiếu thông tin (type, players, jobId, script)' });
  }

  const message =
    `**MIRAGE ISLANDS NOTIFY**\n` +
    `**Type:** ${type}\n` +
    `**Players In Server:** ${players}/12\n` +
    `**Job ID:** \`${jobId}\`\n` +
    `**Join Script:**\n\`\`\`lua\n${script}\n\`\`\``;

  try {
    await axios.post(WEBHOOK_URL, { content: message });
    return res.json({ success: true });
  } catch (err) {
    console.error('Error sending to Discord:', err.message);
    return res.status(500).json({ error: 'Gửi Discord thất bại' });
  }
});

app.listen(PORT, () => {
  console.log(`✅ API running on port ${PORT}`);
});
